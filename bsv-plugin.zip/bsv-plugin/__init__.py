from electroncash.i18n import _

fullname = 'bsv-plugin'
description = _('Plugin bsv-plugin')
available_for = ['qt']
